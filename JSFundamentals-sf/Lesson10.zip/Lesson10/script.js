var names = [];

do  {
    var element = names.pop();
    
    alert(element);
} while (names.length > 0);

alert("this is outside of the loop");