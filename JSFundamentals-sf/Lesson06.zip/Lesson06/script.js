var obj = "This is a string object.",
    length = obj.length; // 24
    
var upperCase = obj.toUpperCase(),
    lowerCase = obj.toLowerCase();


alert(upperCase);
alert(lowerCase);
alert(obj);
