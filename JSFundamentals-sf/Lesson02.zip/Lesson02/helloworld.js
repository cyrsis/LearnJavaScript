var helloWorld = "Hello, World!";
var ten = 10;
var pi = 3.14;
var isBoolean = false;