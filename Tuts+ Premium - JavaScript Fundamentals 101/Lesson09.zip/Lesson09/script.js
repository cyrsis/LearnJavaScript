var foo = null; // undefined

if (foo) {
    alert("hi");
}

alert(typeof null);