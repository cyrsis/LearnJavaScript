var names = ["Jeremy", "Jeffrey"],
    names2 = ["Jennifer", "Jackie"];
    
var people = names.concat(names2);

var joined = people.join(", ");

var reversed = people.reverse();

var sorted = people.sort();

alert(sorted);
