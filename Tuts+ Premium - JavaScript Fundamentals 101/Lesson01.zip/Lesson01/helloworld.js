alert("Hello, World!");
alert("Hello, JavaSCript Fundamentals");