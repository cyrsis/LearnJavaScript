You will need to trigger the NuGet package restore after opening the solution in order for to pull in the neccessary packages.

The admin log in credentials are:
  Username: Admin
  Password: Password1