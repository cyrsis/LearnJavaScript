﻿namespace KendoDreamCarShopper.ViewModels.Common {

    public class LookupItemViewModel {

        public int Id { get; set; }
        public string Text { get; set; }

    }
}