﻿using System.Web.Mvc;

namespace KendoDreamCarShopper.Controllers {

    public class HomeController : Controller {

        public ActionResult Index() {
            return View();
        }
    }
}