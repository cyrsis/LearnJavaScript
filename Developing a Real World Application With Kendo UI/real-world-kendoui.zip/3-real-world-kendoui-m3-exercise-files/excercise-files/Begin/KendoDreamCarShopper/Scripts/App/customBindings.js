﻿
kendo.data.binders.imageSlider = kendo.data.Binder.extend({
    
});