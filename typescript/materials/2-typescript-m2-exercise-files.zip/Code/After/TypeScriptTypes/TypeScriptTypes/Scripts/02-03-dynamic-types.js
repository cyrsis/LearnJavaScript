var demo_02_03;
(function (demo_02_03) {
    var person;
    person = 'John Papa';
    person.substring(1, 4);
    person = 1;
    person.substring(1, 4);
    person = {
        name: 'John Papa',
        age: 40
    };
    person.substring(1, 4);
})(demo_02_03 || (demo_02_03 = {}));
//@ sourceMappingURL=02-03-dynamic-types.js.map
