var alerter = new Alerter();
alerter.showMessage();
