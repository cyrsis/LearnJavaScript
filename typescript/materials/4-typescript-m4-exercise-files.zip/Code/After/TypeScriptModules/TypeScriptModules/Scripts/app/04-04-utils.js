var App;
(function (App) {
    App.LoggerMode = {
        Console: 1,
        Alert: 2,
        Toastr: 3
    };
    (function (Utils) {
        var Logger = (function () {
            function Logger(mode) {
                if (typeof mode === "undefined") { mode = App.LoggerMode.Console; }
                this.mode = mode;
                switch(this.mode) {
                    case App.LoggerMode.Console: {
                        this.writer = function (msg) {
                            return console.log(msg);
                        };
                        break;

                    }
                    case App.LoggerMode.Alert: {
                        this.writer = function (msg) {
                            return alert(msg);
                        };
                        break;

                    }
                    case App.LoggerMode.Toastr: {
                        this.writer = function (msg) {
                            return toastr.info(msg);
                        };
                        break;

                    }
                }
            }
            Logger.prototype.write = function (msg) {
                this.writer(msg);
            };
            return Logger;
        })();
        Utils.Logger = Logger;        
    })(App.Utils || (App.Utils = {}));
    var Utils = App.Utils;
})(App || (App = {}));
//@ sourceMappingURL=04-04-utils.js.map
