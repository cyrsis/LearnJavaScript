var alerter = new Alerter();
alerter.showMessage();
//@ sourceMappingURL=04-05-bootstrapper.js.map
