/// <reference path="../typings/toastr-1.2.d.ts" />
interface IRectangle {
    height: number;
    width: number;
    getArea(): number;
}
module Shapes {

    export class Rectangle implements IRectangle {
        constructor (
            public height: number, 
            public width: number) {
        }
        getArea() { return this.height * this.width; }


    }

}

module MyProgram {

    function run () {
        var rect: IRectangle = new Shapes.Rectangle(10, 4);
        var area = rect.getArea();
        toastr.info("area = " + area);
    }

    run();
}

