var LoggerMode = {
    Console: 1,
    Alert: 2,
    Toastr: 3
};
var App;
(function (App) {
    (function (Tools) {
        (function (Utils) {
            var Logger = (function () {
                function Logger(mode) {
                    if (typeof mode === "undefined") { mode = LoggerMode.Console; }
                    this.mode = mode;
                    switch(this.mode) {
                        case LoggerMode.Console: {
                            this.writer = function (msg) {
                                return console.log(msg);
                            };
                            break;

                        }
                        case LoggerMode.Alert: {
                            this.writer = function (msg) {
                                return alert(msg);
                            };
                            break;

                        }
                        case LoggerMode.Toastr: {
                            this.writer = function (msg) {
                                return toastr.info(msg);
                            };
                            break;

                        }
                    }
                }
                Logger.prototype.write = function (msg) {
                    this.writer(msg);
                };
                return Logger;
            })();
            Utils.Logger = Logger;            
        })(Tools.Utils || (Tools.Utils = {}));
        var Utils = Tools.Utils;
    })(App.Tools || (App.Tools = {}));
    var Tools = App.Tools;
})(App || (App = {}));
var App;
(function (App) {
    (function (Tools) {
        (function (Shapes) {
            var Point = (function () {
                function Point(x, y) {
                    this.x = x;
                    this.y = y;
                }
                Point.prototype.getDist = function () {
                    return Math.sqrt(this.x * this.x + this.y * this.y);
                };
                return Point;
            })();
            Shapes.Point = Point;            
        })(Tools.Shapes || (Tools.Shapes = {}));
        var Shapes = Tools.Shapes;
    })(App.Tools || (App.Tools = {}));
    var Tools = App.Tools;
})(App || (App = {}));
var App;
(function (App) {
    (function (Tools) {
        (function (Shapes) {
            var Rectangle = (function () {
                function Rectangle(height, width) {
                    this.height = height;
                    this.width = width;
                }
                Rectangle.prototype.getPerimeter = function () {
                    return this.height * 2 + this.width * 2;
                };
                Rectangle.prototype.getArea = function () {
                    return this.height * this.width;
                };
                return Rectangle;
            })();
            Shapes.Rectangle = Rectangle;            
        })(Tools.Shapes || (Tools.Shapes = {}));
        var Shapes = Tools.Shapes;
    })(App.Tools || (App.Tools = {}));
    var Tools = App.Tools;
})(App || (App = {}));
var Tools = App.Tools;
var log = new Tools.Utils.Logger(LoggerMode.Toastr);
var p = new Tools.Shapes.Point(3, 4);
var dist = p.getDist();
log.write("distance = " + dist);
var rect = new Tools.Shapes.Rectangle(10, 4);
var perimeter = rect.getPerimeter();
log.write("perimeter = " + perimeter);
//@ sourceMappingURL=04-03-extending-internal-module.js.map
