require.config({
    baseUrl: "scripts/amd-basic"
});
require([
    "bootstrapper"
], function (boot) {
    boot.run();
});
//@ sourceMappingURL=main.js.map
